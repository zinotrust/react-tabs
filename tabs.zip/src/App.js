import "./App.scss";
import Tabs from "./components/tabs/Tabs";

function App() {
  return (
    <div>
      <Tabs />
    </div>
  );
}

export default App;
